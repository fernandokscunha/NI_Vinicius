package com.example.ni_escobar;

public class Item {
    String nome;
    String status;
    int modificador;
    int icon;

    public Item(String nome, String status, int modificador, int icon){
        this.nome = nome;
        this.status = status;
        this.modificador = modificador;
        this.icon = icon;
    }
}
